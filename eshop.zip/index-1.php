<!doctype html>
<html>
	<head>
		<title>eShop PHP & MySQL & Bootstrap</title>
		<meta charset="utf-8" />
		
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>
	<body>
		<div class="container-fluid">
			<header class="row">
				<div id="logo" class="col-12 col-md-3 col-xl-2" >LOGO
				</div>
				<div id="search" class="col-9 col-md-7 col-xl-8" >Search Bar
				</div>
				<div id="basket-account" class="col-3 col-md-2 col-xl-2">Basket
				</div>
			</header>
		</div>
		<div class="container" >
			<section id="slideshow" class="row">
				<div class="col-12">
					slideshow
				</div>
			</section>
		</div>
		<div class="container-fluid">
			<section id="new-products" class="row">
				<div class="col-12  col-sm-6  col-md-4 col-lg-2">
					Προϊόν Α
				</div>
				<div class="col-12  col-sm-6  col-md-4 col-lg-2">
					Προϊόν Β
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Γ
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Δ
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Ε
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν ΣΤ
				</div>
			</section>
		</div>
		<div class="container-fluid">
			<section id="offer-products" class="row">
				<div class="col-12 col-sm-6 col-md-4 col-lg-2 ">
					Προϊόν Α
				</div>
				<div class="col-12  col-sm-6  col-md-4 col-lg-2">
					Προϊόν Β
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Γ
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Δ
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν Ε
				</div>
				<div class="col-12 col-sm-6  col-md-4 col-lg-2">
					Προϊόν ΣΤ
				</div>
			</section>
		</div>
		<div class="container">
			<footer class="row">
				<div class="col-12 col-sm-6 col-lg-3">footer 1</div>
				<div class="col-12 col-sm-6 col-lg-3">footer 2</div>
				<div class="col-12 col-sm-6 col-lg-3">footer 3</div>
				<div class="col-12 col-sm-6 col-lg-3">
					<div class="row">
						<div class="col-12">2310 226318</div>
					</div>
					<div class="row">
						<div class="col-6">BLOG</div>
						<div class="col-6">Youtube</div>
						<div class="col-6">Radio</div>
						<div class="col-6">Κατάλογοι</div>
					</div>
					<div class="row">
						<div class="col-12">
							Social Media
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							Social Media
						</div>
					</div>
				</div>
			</footer>
		</div>
	</body>
</html>