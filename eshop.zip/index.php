<?php
	require_once("includes/connection.php");  
	require_once("includes/models/newproducts.php");
	require_once("includes/models/offersproducts.php");
	require_once("includes/models/categories.php");
	
	$message=array('status'=>true,
					'msg'=>'το κατάστημα μας θα παραμείνει κλειστό!!');
?>
<!doctype html>
<html>
	<head>
		<title>eShop PHP & MySQL & Bootstrap</title>
		<?php
			require_once('includes/head.php');
			require_once('includes/init/slideshow.php');
		?>
	</head>
	<body>
		<div class="modal fade" id="enimerosi" tabindex="-1">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title">Ενημέρωση προς το κοινό!!</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				<p>
					<?php 
						if($message['status'])
							echo $message['msg'];
					?>
				</p>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			  </div>
			</div>
		  </div>
		</div>
		<?php
		//require require_once include include_once ολα ειναι πανομοιοτυπα.
		// require # include = include εμφανιζει το error ενω το require οχι.
		// το once χρησιμοποιειται μονο μια φορα 
			require_once('includes/header.php'); 
			require_once('includes/nav.php'); 
			require_once('includes/slideshow.php'); 
			require_once('includes/new-products.php'); 
			require_once('includes/offer-products.php'); 
			require_once('includes/footer.php'); 
		?>
	</body>	
	<script>
		//selector.event
		$('.basket').click(function(event){
			event.preventDefault();//μπλοκάρει την default λειτουργία το tag a,που είναι το άνοιγμα ενός συνδέσμου
			//alert($(this).data('alias')+"\n"+$(this).data('action'));
			$.ajax({
				  type: "GET", //μέθοδος αποστολής των δεδομένων
				  contentType: "application/json; charset=utf-8", //JSON - RES
						/* μορφή πληροφορίας JSON
						{'όνομα μεταβλητής':'τιμή',
						'όνομα μεταβλητής':'τιμή',
						'όνομα μεταβλητής':'τιμή'}	
						*/
				  url: "basket.php",
				  data: { 'action':$(this).data('action')  , 'pid': $(this).data('alias'),'name':  $(this).data('name'),'price':  $(this).data('price')},
				  success: function (returned_data) { 
					//οτι κάνει echo η basket.php επιστρέφεται στην μεταβλητή returned_data
					var obj = jQuery.parseJSON( returned_data );//μετατρέπει json σε object
					console.log(obj);
					if(obj.status){
						$('#mini-basket').css("display","block");
						//$('#mini-basket-body').html(JSON.stringify(obj.products));
						//η συνάρτηση html ορίζει περιεχόμενο για το tag με id=mini-basket-body
						var total_amount=0;
						var total_price=0;
						$('#mini-basket-body').html('');
						$.each(obj.products, function(i, item) {//δομή επανάληψης
							total_amount+=item.amount; //σύνολο τεμαχίων
							total_price+=total_amount*item.price; //συνολική αξία
						//$.each(πίνακας - array, function(δείκτης, τιμή)
							$('#mini-basket-body').append('<div class="mini-basket-item">'+item.name+' / '+item.amount+' / '+item.price+'&euro;</div>');
							//console.log(item.pid);
						});
						$('#mini-basket-total').html(total_amount+' τεμάχια, '+total_price+'&euro;');
						//alert(obj.msg);
					}
					//alert( obj.name === "John" );
					//alert('το προιόν προστέθηκε με επιτυχία στο καλάθι');
					 //console.log(returned_data);
				  },
				   error: function(){
				   },
				   complete: function(){
				   }
			 });
		});
		
		<?php 
			// if($message['status']) { ?>
			// $(document).ready(function(){ //όταν φορτώσει όλη η σελίδα
			// 	$('#enimerosi').delay(5000).modal('show');
			// });
		<?php 
	//} 
	?>
		
		
		$("#closeminibasket").click(function(){
			console.log('asdasd');
			$('#mini-basket').css("display","none");			
		});
	</script>
</html>