<?php
	require_once("includes/connection.php");  
	require_once("includes/models/search.php");
	require_once("includes/models/categories.php");
?>
<!doctype html>
<html>
	<head>
		<title>eShop PHP & MySQL & Bootstrap</title>
		<?php
			require_once('includes/head.php');
		?>
	</head>
	<body>
		<?php
			require_once('includes/header.php'); 
			require_once('includes/nav.php');			
			require_once('includes/search.php'); 
			require_once('includes/footer.php'); 
		?>
	</body>	
</html>