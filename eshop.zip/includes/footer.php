<div>
	<div id="banner">
		<img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/banner2.jpg" alt="" style="margin-top:200px;width:100%;height:400px">
	</div>
</div>
    <footer>
      <div class="main-content">
        <div class="left box">
          <h2>About us</h2>
          <div class="content">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati iste ad, ratione, possimus iure, at repellendus vitae beatae perspiciatis blanditiis magnam officiis nostrum? Dolore, natus magnam. Veritatis itaque numquam expedita.
			Ab exercitationem totam mollitia illo saepe ullam est, asperiores, natus earum, magni qui iste similique deleniti fugiat commodi iusto ut voluptatem rerum sint debitis culpa eius veniam! Architecto, officiis molestias..</p>
            <div class="social">
              <a href="#"><span class="fab fa-facebook-f"></span></a>
              <a href="#"><span class="fab fa-twitter"></span></a>
              <a href="#"><span class="fab fa-instagram"></span></a>
              <a href="#"><span class="fab fa-youtube"></span></a>
            </div>
          </div>
        </div>
        <div class="center box">
          <h2>Address</h2>
          <div class="content">
            <div class="place">
              <span class="fas fa-map-marker-alt"></span>
              <span class="text">Thessaloniki, Greece</span>
            </div>
            <div class="phone">
              <span class="fas fa-phone-alt"></span>
              <span class="text">+30-69xxxxxxxx</span>
            </div>
            <div class="email">
              <span class="fas fa-envelope"></span>
              <span class="text">example@example.com</span>
            </div>
          </div>
        </div>
        <div class="right box">
          <h2>Contact us</h2>
          <div class="content">
            <form action="#">
              <div class="email">
                <div class="text">Email *</div>
                <input type="email" required>
              </div>
              <div class="msg">
                <div class="text">Message *</div>
                <textarea rows="2" cols="25" required></textarea>
              </div>
              <div class="btn">
                <button type="submit">Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="bottom">
        <center>
          <span class="credit">Created By <a href="#">Lavidas Anastasios</a> | </span>
          <span class="far fa-copyright"></span><span> 2021 PHP Karadimos.</span>
        </center>
      </div>
    </footer>