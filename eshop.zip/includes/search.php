<div class="container-fluid">
	<section id="new-products" class="row">
		<div id="new-products-title" class="col-12">
			<h2>Αναζήτηση του <?=$_POST['keyword']?></h2>		
		</div>
		<?php
		//3o εκτύπωση εγγραφών από το $products_recordset
		while($products_record=mysqli_fetch_assoc($search_recordset)){ 
			//mysqli_fetch_assoc διαβάζει ένα record απο το recordset $categories_recordset και το επιστρ΄φει σε μορφή array της PHP
		?>
			<div class="product_item col-12 col-sm-6 col-md-4 col-lg-2">					
				<div class="product-image"><img class="w-100" src="<?=dirname($_SERVER["PHP_SELF"])?>/images/products/<?=$products_record['productsID']?>.jpg" alt="<?=$products_record['productsNAME']?>" /></div>
				<div class="product-name">
					<h3 class="display-6">
						<a href="<?=$products_record['catALIAS']?>/<?=$products_record['subcatALIAS']?>/<?=$products_record['productsALIAS']?>">
							<?=$products_record['productsNAME']?>
						</a>
					</h3>
				</div>
				<div class=" <?=$products_record['productsOFFERPRICE']>0?'disable-price':''?> product-price"><?=$products_record['productsPRICE']?></div>
				<?php if($products_record['productsOFFERPRICE']>0) {?>
					<div class="product-offer"><?=$products_record['productsOFFERPRICE']?></div>
				<?php } ?>
				<div class="product-footer">
					<a class="basket"   data-price="<?=$products_record['productsOFFERPRICE']>0?$products_record['productsOFFERPRICE']:$products_record['productsPRICE']?>"
										data-name="<?=$products_record['productsNAME']?>" 
										data-alias="<?=$products_record['productsALIAS']?>" 
										data-action="add" href="#">
						<i class="fas fa-cart-plus"></i>
					</a>
				</div>
			</div>
		<?php }	?>
	</section>
</div>