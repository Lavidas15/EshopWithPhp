<?php
function getcatname($catalias){
	GLOBAL $con;
	$catq="select name from categories
	where alias like '".$catalias."'";
	mysqli_query($con,"set name 'utf8'");
	$r=mysqli_query($con,$catq);
	$d=mysqli_fetch_assoc($r);
	return $d['name'];
}

function getsubcatname($subcatalias){
	GLOBAL $con;
	$catq="select name from subcategories
	where alias like '".$subcatalias."'";
	mysqli_query($con,"set name 'utf8'");
	$r=mysqli_query($con,$catq);
	$d=mysqli_fetch_assoc($r);
	return $d['name'];
}
?>