<div id="mini-basket">
	<div id="mini-basket-header">
		<h4>Καλάθι αγοράς (mini)</h4>
	</div>
	<div id="mini-basket-body">
		
	</div>
	<div id="mini-basket-total">
	</div>
	<div id="mini-basket-footer">
		<button id="closeminibasket" type="button" class="btn btn-primary">Κλείσιμο</button>
	</div>
</div>
<div class="container-fluid">
	<header class="row">
		
		<div id="logo" class="col-12 col-md-4 col-xl-2" >
			<img  src="<?=dirname($_SERVER["PHP_SELF"])?>/images/logo.png" style="width:200px;" alt="eshop" />
		</div>
		<div id="search" class="col-9 col-md-7 col-xl-8" >
			<form style="margin-top:30px;" action="<?=dirname($_SERVER["PHP_SELF"])?>/search.php" method="post">
				<input type="search" class="rounded-pill  border-1 bg-light form-control" name="keyword" placeholder="Ψάχνεις για..." />
			</form>
		</div>
		<div id="basket-account" class="pt-2 col-3 col-md-1 col-xl-1">
			<div class="row">				
				<div id="account" class="col-6 text-center">
					<a href="account.php">
						<i id="cartaki" class="fas fa-user"></i>
					</a>
				</div>
				<div id="basket"  class="col-6 text-center">
					<a href="basket.php">
						<i id="bsk" class="fas fa-shopping-cart"></i>
					</a>
				</div>
			</div>
		</div>
	</header>
</div>
