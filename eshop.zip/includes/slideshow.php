<div  class="container">
	<section id="slideshow" class="row">
		<div class="col-12 col-sm-12 col-lg-12">
			<div id="banner-carousel" class="carousel slide" data-bs-ride="carousel">
				 <ol class="carousel-indicators">
					<li data-target="#banner-carousel" data-slide-to="0" class="active"></li>
					<li data-target="#banner-carousel" data-slide-to="1"></li>
					<li data-target="#banner-carousel" data-slide-to="2"></li>
					<li data-target="#banner-carousel" data-slide-to="3"></li>
				  </ol>
				  <div class="carousel-inner">
					<div class="carousel-item active">
					  <img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/bg-img.jpg" class="d-block w-100" style="height:600px"  alt="bg-img">
					</div>
					<div class="carousel-item">
					  	<div class="row">
							 <img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/rtx-3080-2.jpg" class="d-block w-100" style="height:600px"  alt="">
						</div>
					</div>
					<div class="carousel-item">
					  	<div class="row">
							 <img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/rtx-3080-3.jpg" class="d-block w-100" style="height:600px"  alt="">
						</div>
					</div>
					<div class="carousel-item">
					  	<div class="row">
							 <img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/rtx-3080-4.jpg" class="d-block w-100" style="height:600px"  alt="">
						</div>
					</div>
				  </div>
				  
				<a class="carousel-control-prev" href="#banner-carousel" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#banner-carousel" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				  </a> 
				</div>
			</div>
		</div>
	</section>
</div>
