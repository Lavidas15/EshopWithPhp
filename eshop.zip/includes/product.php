<div class="container-fluid">
	<section id="new-products" class="row">
		
		
			<div id="alone-prod" class="product_item col-12 col-sm-6 col-md-4 col-lg-2">					
				<div  class="product-image"><img class="w-100" src="<?=dirname($_SERVER["PHP_SELF"])?>/images/products/<?=$product_data['productsID']?>.jpg" alt="<?=$product_data['productsNAME']?>" /></div>
				<div class="product-name">
					<h3 id="dis6" class="display-6">
						<a href="<?=$product_data['catALIAS']?>/<?=$product_data['subcatALIAS']?>/<?=$product_data['productsALIAS']?>">
							<?=$product_data['productsNAME']?>
						</a>
					</h3>
				</div>
				<div  class=" <?=$product_data['productsOFFERPRICE']>0?'disable-price':''?> product-price"><?=$product_data['productsPRICE']?></div>
				<?php if($product_data['productsOFFERPRICE']>0) {?>
					<div id="price-only" class="product-offer"><?=$product_data['productsOFFERPRICE']?></div>
				<?php } ?>
				<div class="product-footer displayFooter">
					<a class="basket"   data-price="<?=$product_data['productsOFFERPRICE']>0?$product_data['productsOFFERPRICE']:$product_data['productsPRICE']?>"
										data-name="<?=$product_data['productsNAME']?>" 
										data-alias="<?=$product_data['productsALIAS']?>" 
										data-action="add" href="#">
						<i class="fas fa-cart-plus"></i>
					</a>
					<button id="btnBasket">Preview</button>
				</div>
			</div>
			<div class="productDescription">
				<p style="font-size:23px;">To <?=$product_data['productsNAME']?> έχει τα εξής:<br> <?=$product_data['productsLDESC']?>.</p>
				<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptate dolorem asperiores labore iste et optio laboriosam tenetur molestias in repellat at, eum quae saepe. Atque, cupiditate esse? Illo, aperiam quo?
			Dolorem itaque modi molestias magnam soluta cumque eos deserunt, odit impedit quas, at optio, earum magni vel delectus sit nihil! Labore, aut laudantium porro sapiente fugiat blanditiis officiis amet quos.
			Voluptate blanditiis pariatur dicta aliquid quis ratione nesciunt dignissimos! Dignissimos illo, nulla placeat, quae, cum quis quas suscipit ullam cumque quasi blanditiis animi nobis eius magni ipsum quidem modi veniam.
			Adipisci blanditiis sequi, dolorem porro ipsum provident eum quae vitae quia error sit, placeat ad recusandae dolores ab facere accusantium iusto consectetur praesentium maxime voluptatibus architecto. Inventore ratione similique maiores?
			Praesentium a tenetur dignissimos provident velit itaque iste ut nobis nisi? Iste porro voluptate commodi minima illum, excepturi, a, illo distinctio nam at ea pariatur placeat in dolore eaque vero?
			Natus incidunt repudiandae saepe tenetur aperiam amet enim ea quis, architecto, nesciunt vel, ducimus illum eveniet explicabo. In voluptates laborum doloremque temporibus. Atque et a obcaecati libero id impedit earum.
			Inventore exercitationem consectetur id reprehenderit doloremque officia voluptates! Nisi veniam provident laborum excepturi illum nihil, ratione eveniet minus repudiandae aperiam autem distinctio tenetur voluptatem atque! Eum magni debitis fugit consequuntur.
			Aspernatur, distinctio repellat nulla facilis, tempore sit recusandae, illo voluptatem atque vel hic! Molestias, dicta impedit asperiores id quisquam optio nihil ratione explicabo. Delectus soluta incidunt accusamus, aspernatur corporis consequuntur.
			Architecto veritatis a facere, obcaecati officiis, similique aliquid cum aliquam accusantium molestiae non minima. Beatae vitae ut qui magni illum nesciunt hic quam, commodi maxime. Unde beatae rerum maiores non.
			Quas magnam eligendi, molestias rerum architecto fuga quae laborum repellat, tempore tenetur ut nostrum ea repellendus! Obcaecati quae saepe tempore magnam vitae commodi debitis, explicabo, voluptatem culpa repellat facilis laboriosam?<p></div>
	</section>
</div>