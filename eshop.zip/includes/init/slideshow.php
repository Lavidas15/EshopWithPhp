<script>
	$(document).ready(function(){
		$("#banner-carousel").carousel({		
			interval: 10000,
			keyboard:true
		});
	});
</script>