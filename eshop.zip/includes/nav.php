<div class="container-fluid" id="containerFluid" >
	<div class="row" >
		<nav class="navbar navbar-expand-lg navbar-light " >
		  
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNavDropdown">
			<ul class="navbar-nav" >
			  <li class="nav-item active"  >
				<a class="nav-link"  href="<?=dirname($_SERVER["PHP_SELF"])?>">Home</a>
			  </li>			 
			  
			  
			  <?php
					//3o εκτύπωση εγγραφών από το $categories_recordset
					while($categories_record=mysqli_fetch_assoc($categories_recordset)){ 
						//mysqli_fetch_assoc διαβάζει ένα record απο το recordset $categories_recordset και το επιστρ΄φει σε μορφή array της PHP
						
						//eshop subcategories 
						$subcategories_query="SELECT * FROM subcategories where categories_id like ".$categories_record['id'];
						mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
						$subcategories_recordset=mysqli_query($con,$subcategories_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
					?>
					  <li id="navDrop" class="nav-item dropdown"  >
						<a  class="nav-link dropdown-toggle" href="<?=dirname($_SERVER["PHP_SELF"])?>/<?=$categories_record['alias']?>.html" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  <?=$categories_record['name']?>	
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<?php 
								//τυπώνει τις υποκατηγορίες
								while($subcategories_record=mysqli_fetch_assoc($subcategories_recordset)){  ?>
								  <a class="dropdown-item" href="<?=dirname($_SERVER["PHP_SELF"])?>/<?=$categories_record['alias']?>/<?=$subcategories_record['alias']?>">
									<?=$subcategories_record['name']?>
								  </a>								
								<?php } ?>
						</div>
					  </li>
				<?php }?>
			  
			</ul>
		  </div>
		</nav>
	</div>
</div>
<div>
	<div id="banner">
		<img src="<?=dirname($_SERVER["PHP_SELF"])?>/images/banners/banner1.png" alt="" style="width:100%;height:800px">
	</div>
</div>