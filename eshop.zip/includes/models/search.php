<?php 
	//eshop products
	$search_query="select 
						a.id as productsID,
						a.name as productsNAME,
						a.price as productsPRICE,
						a.`offer-price` as productsOFFERPRICE,
						a.alias as productsALIAS,
						b.alias as subcatALIAS,
						b.name as subcatNAME,
						c.alias as catALIAS,
						c.name as catNAME
						from products a
						inner join subcategories b on a.subcategories_id=b.id
						inner join categories c on b.categories_id=c.id 
						where a.name like '%".$_POST['keyword']."%' 
								or a.`long-description` like '%".$_POST['keyword']."%'
								or a.`short-description` like '%".$_POST['keyword']."%'";
	/* limit ορίζει το όριο των εγγραφών που θα μου επιστρέψει η MySQL 0=το record αρχής , 6= ο αριθμός των εγγραφών (0=από , 6= πόσα) */
	mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
	$search_recordset=mysqli_query($con,$search_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
?>

