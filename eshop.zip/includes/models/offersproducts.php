<?php 
	//eshop products
	$offerproducts_query="SELECT id,name,`offer-price`,price,alias FROM products 
						where `offer-price`>0  
						order by RAND()
						limit 0,6"; 
	/* limit ορίζει το όριο των εγγραφών που θα μου επιστρέψει η MySQL 0=το record αρχής , 6= ο αριθμός των εγγραφών (0=από , 6= πόσα) */
	mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
	$offerproducts_recordset=mysqli_query($con,$offerproducts_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
?>