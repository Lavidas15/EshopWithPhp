<?php 
	//eshop products
	$newproducts_query="select 
						a.id as productsID,
						a.name as productsNAME,
						a.price as productsPRICE,
						a.`offer-price` as productsOFFERPRICE,
						a.alias as productsALIAS,
						b.alias as subcatALIAS,
						c.alias as catALIAS
						from products a
						inner join subcategories b on a.subcategories_id=b.id
						inner join categories c on b.categories_id=c.id 
						where insert_date >= '".date("Y-m-d",strtotime(date("d-m-Y",time())." -1 year"))."' limit 0,6"; 
	/* limit ορίζει το όριο των εγγραφών που θα μου επιστρέψει η MySQL 0=το record αρχής , 6= ο αριθμός των εγγραφών (0=από , 6= πόσα) */
	mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
	$newproducts_recordset=mysqli_query($con,$newproducts_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
?>