<?php
$categories_query="SELECT * FROM categories";
mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
$categories_recordset=mysqli_query($con,$categories_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
?>
