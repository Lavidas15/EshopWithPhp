<?php 
	//eshop products
	$product_query="select 
	a.id as productsID,
	a.name as productsNAME,
	a.`short-description` as productsSDESC,
	a.`long-description` as productsLDESC,
	a.amount as productsTEMAXIA,
	a.sku as productsSKU,
	a.warranty as productsWARRANTY,
	a.weight as productsWEIGHT,
	a.height as productsHEIGHT,
	a.width as productsWIDTH,
	a.price as productsPRICE,
	a.`offer-price` as productsOFFERPRICE,
	a.alias as productsALIAS,
	b.alias as subcatALIAS,
	b.name as subcatNAME,
	c.alias as catALIAS,
	c.name as catNAME
	from products a
	inner join subcategories b on a.subcategories_id=b.id
	inner join categories c on b.categories_id=c.id 
	where a.alias like '".$_GET['prodalias']."'"; 
	
	/* limit ορίζει το όριο των εγγραφών που θα μου επιστρέψει η MySQL 0=το record αρχής , 6= ο αριθμός των εγγραφών (0=από , 6= πόσα) */
	mysqli_query($con,"set names 'utf8'");//ορίζει encoding  utf8 στα αποτελέσματα της MySQL
	$product_recordset=mysqli_query($con,$product_query);//εκτελεί ενα ερω΄τημα προς την MySQL kai επιστρέφει ενα Recordset
	$product_data=mysqli_fetch_assoc($product_recordset);
?>