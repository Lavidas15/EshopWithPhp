<?php
	require_once("includes/connection.php");  
	require_once("includes/models/categories.php");
	require_once("includes/models/product.php");
?>
<!doctype html>
<html>
	<head>
		<title>eShop PHP & MySQL & Bootstrap</title>
		<?php
			require_once('includes/head.php');
		?>
	</head>
	<body>
		<?php
			require_once('includes/header.php'); 
			require_once('includes/nav.php'); 
			require_once('includes/product.php'); 
			require_once('includes/footer.php'); 
		?>
	</body>	
</html>