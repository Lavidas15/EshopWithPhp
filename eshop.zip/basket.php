	<?php
		session_start();
		function updatebaskettemaxia($pid,$amount){
			foreach($_SESSION['basket'] as $pointer=>$product){
					if($product['pid']==$pid){						
						$_SESSION['basket'][$pointer]['amount']=$amount; //αυξάνει την τιμή των τεμαχίων κατά μια μονάδα
					}
				}
		}
	
		if(!empty($_POST)){
			foreach($_POST as $pid=>$amount){
				updatebaskettemaxia($pid,$amount);
			}
			header("location:basket.php");
		}
		
		if(isset($_GET['action']) && $_GET['action']=="clear"){
			if(isset($_SESSION['basket'])){
				unset($_SESSION['basket']);//unset διαγραφή την μεταβλητή απο την μνήμη
				echo 'Το καλάθι άδειασε!!';
			}
		}	
		if(isset($_GET['action']) && $_GET['action']=="add"){
			if(!isset($_SESSION['basket'])){
				$_SESSION['basket'][]=array("pid"=>$_GET['pid'],
										"amount"=>1,
										"name"=>$_GET['name'],
										"price"=>$_GET['price']);
				
			} else {
				$found=false;
				foreach($_SESSION['basket'] as $pointer=>$product){
					if($product['pid']==$_GET['pid']){
						$found=true;
						$_SESSION['basket'][$pointer]['amount']++; //αυξάνει την τιμή των τεμαχίων κατά μια μονάδα
					}
				}
				if(!$found){
					$_SESSION['basket'][]=array("pid"=>$_GET['pid'],
											"amount"=>1,
											"name"=>$_GET['name'],
											"price"=>$_GET['price']);
				}
			} 
			$msg=array("status"=>true,
						"msg"=>'Το προιόν προστέθηκε με επιτυχία στο καλάθι!!',
						"products"=>$_SESSION['basket']);
			echo json_encode($msg);//μετατρέπουμε το array σε JSON format
		}
		
		if(isset($_GET['action']) && $_GET['action']=="remove"){
			foreach($_SESSION['basket'] as $pointer=>$product){
					if($product['pid']==$_GET['pid']){						
						unset($_SESSION['basket'][$pointer]); //αυξάνει την τιμή των τεμαχίων κατά μια μονάδα
						header("location:basket.php");
					}
				}
		}
	?>